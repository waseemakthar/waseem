package com.example.lms.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class Librarian extends AppCompatActivity {
    Button addb, bookd, logout;
    Spinner selto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_librarian);
        addb=(Button)findViewById(R.id.button3);
        bookd=(Button)findViewById(R.id.button4);
        logout=(Button)findViewById(R.id.button5);
        selto=(Spinner)findViewById(R.id.spinner2) ;
        List<String> val1=new ArrayList<>();
        val1.add("Select");
        val1.add("View Book");
        val1.add("Issue Book");
        val1.add("View Issued Book");
        val1.add("Return Book");
        ArrayAdapter<String> da=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,val1);
        da.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selto.setAdapter(da);

    }
    public void gostaff(View v){
        Intent i = new Intent(Librarian.this,Staff.class);
        startActivity(i);
    }
}
