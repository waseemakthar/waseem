package com.example.lms.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText name, pwd;
    Spinner sel;
    Button login, register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = (EditText) findViewById(R.id.editText);
        pwd = (EditText) findViewById(R.id.editText2);
        sel = (Spinner) findViewById(R.id.spinner);
        login = (Button) findViewById(R.id.button);
        register = (Button) findViewById(R.id.button2);
        //String val1[]={"Select","Librarian","Staff","Student"};
        List<String> val1 = new ArrayList<>();
        val1.add("Select");
        val1.add("Librarian");
        val1.add("Staff");
        val1.add("Student");
        ArrayAdapter<String> da = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val1);
        da.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sel.setAdapter(da);
    }
    public void login1(View v){
        Intent i = new Intent(MainActivity.this,Librarian.class);
        startActivity(i);
    }
    public void reg1(View v){
        Intent i = new Intent(MainActivity.this,Student.class);
        startActivity(i);
    }
}
