package com.example.lms.lms;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class Staff extends AppCompatActivity {
    EditText name, fac;
    Spinner opt;
    Button logout, booktaken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);
        name =(EditText)findViewById(R.id.editText8);
        fac =(EditText)findViewById(R.id.editText7);
        opt =(Spinner)findViewById(R.id.spinner6);
        logout=(Button)findViewById(R.id.button8);
        booktaken=(Button)findViewById(R.id.button9);
        List<String> val1 = new ArrayList<>();
        val1.add("Option");
        val1.add("PREQUEST");
        val1.add("BOOKSELF");
        val1.add("TABLEREG");
        ArrayAdapter<String> da1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val1);
        da1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        opt.setAdapter(da1);
    }
}
