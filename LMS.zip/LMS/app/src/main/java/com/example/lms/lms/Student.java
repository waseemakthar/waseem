package com.example.lms.lms;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class Student extends AppCompatActivity {
    EditText reno, frstn, lstn;
    Spinner dpt, cours, yr;
    Button save, cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        reno = (EditText) findViewById(R.id.editText3);
        frstn = (EditText) findViewById(R.id.editText5);
        lstn = (EditText) findViewById(R.id.editText6);
        dpt = (Spinner) findViewById(R.id.spinner3);
        cours = (Spinner) findViewById(R.id.spinner4);
        yr = (Spinner) findViewById(R.id.spinner5);
        save = (Button) findViewById(R.id.button);
        cancel = (Button) findViewById(R.id.button);
        List<String> val1 = new ArrayList<>();
        val1.add("Select");
        val1.add("CSE");
        val1.add("IT");
        ArrayAdapter<String> da1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val1);
        da1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dpt.setAdapter(da1);
        List<String> val2 = new ArrayList<>();
        val2.add("Select");
        val2.add("B.TECH");
        val2.add("M.TECH");
        ArrayAdapter<String> da2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val2);
        da2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cours.setAdapter(da2);
        List<String> val3 = new ArrayList<>();
        val3.add("Select");
        val3.add("1");
        val3.add("2");
        val3.add("3");
        val3.add("4");
        ArrayAdapter<String> da3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val3);
        da3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yr.setAdapter(da3);
    }
}












