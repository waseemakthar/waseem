package com.example.lms.lms;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

public class Librarian2 extends AppCompatActivity {
EditText til, isu, auth;
    Button save, cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_librarian2);
        til=(EditText)findViewById(R.id.editText9);
        isu=(EditText)findViewById(R.id.editText10);
        auth=(EditText)findViewById(R.id.editText11);
        save =(Button)findViewById(R.id.button10);
        cancel=(Button)findViewById(R.id.button11);
    }
}
